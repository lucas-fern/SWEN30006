package cribbage;

/* Modified by Workshop 9, Team 2 for SWEN30006 Project 2 */

public interface CribbageObserver {
    void update(CribbageEvent event);
}
